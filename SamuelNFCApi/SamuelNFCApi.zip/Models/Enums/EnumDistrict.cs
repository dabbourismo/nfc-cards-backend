﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SamuelNFCApi.Models.Enums
{
    public enum EnumDistrict
    {
        Damanhour
    }
}